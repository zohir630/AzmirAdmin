# Jogipal Admin Panel — সেটআপ (একবারই করতে হবে)

1. Firebase Console (project: ztsong) → Authentication → Sign-in method → **Email/Password** চালু করুন।
2. Authentication → Users → **Add user** দিয়ে আপনার অ্যাডমিন ইমেইল ও পাসওয়ার্ড বানান। User UID কপি করুন।
3. (এখন আর লাগে না) প্রথম লগইনে প্যানেল নিজেই প্রথম অ্যাডমিন বানিয়ে নেয়।
   (অথবা প্রথমবার লগইন করলে স্ক্রিনেই UID দেখাবে)
4. Realtime Database → **Rules** ট্যাবে `database.rules.json` এর কন্টেন্ট পেস্ট করে Publish করুন।
5. Authentication → Settings → Authorized domains এ `<username>.github.io` যোগ করুন।
6. GitHub repo-তে ফাইলগুলো আপলোড → Settings → Pages → Deploy from branch (main / root)।
7. অ্যাডমিন প্যানেলে লগইন → ড্যাশবোর্ড → "ডিফল্ট ডেটা লোড করুন"।

নোট: ছবি আপলোড করলে ছোট করে Database-এ রাখা হয় (Storage লাগে না)। বড় ছবির জন্য ছবির লিংক ব্যবহার করুন।
